### Environment

    NetMQ Version:    
    Operating System: 
    .NET Version:     

### Expected behaviour



### Actual behaviour



### Steps to reproduce the behaviour

