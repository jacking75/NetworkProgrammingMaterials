Devices
===

See:

* http://api.zeromq.org/2-1:zmq-device
* `IDevice` and `DeviceBase`
* `ForwarderDevice`
* `QueueDevice`
* `StreamerDevice`
