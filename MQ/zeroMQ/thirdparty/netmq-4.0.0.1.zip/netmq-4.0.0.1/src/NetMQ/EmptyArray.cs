namespace NetMQ
{
    internal static class EmptyArray<T>
    {
        public static readonly T[] Instance = new T[0];
    }
}