# Permission to Relicense under MPLv2 or any other OSI approved license chosen by the current ZeroMQ BDFL

This is a statement by Nathan Toone that grants permission to
relicense its copyrights in the libzmq C++ library (ZeroMQ) under the
Mozilla Public License v2 (MPLv2) or any other Open Source Initiative
approved license chosen by the current ZeroMQ BDFL (Benevolent
Dictator for Life).

A portion of the commits made by the Github handle "toonetown", with
commit author "Nathan Toone <nathan@toonetown.com>", are
copyright of Nathan Toone.  This document hereby grants the libzmq
project team to relicense libzmq, including all past, present and
future contributions of the author listed above.

Nathan Toone
2018/11/05

