#include "PeerNet.hpp"
//	This file is only present to allow Visual Studio to accurately code-complete this header-only-library
//	Actual use of the library does not require this file or require direct compilation of PeerNet
//	Simply #include PeerNet.hpp and point your projects additional header include directory to the appropriate folder